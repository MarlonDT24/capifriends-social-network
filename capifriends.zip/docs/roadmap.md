## Milestone 1 — Base del proyecto ✅
- [x] Next.js + Tailwind
- [x] Repo GitHub y documentación base
- [x] Supabase: variables env + clientes (browser/SSR)
- [x] Auth: signup/login + sesión (route group `(auth)`)

## Milestone 2 — Perfil y Feed (en progreso)
- [x] Tabla `profiles` con RLS + trigger de provisioning
- [x] Formulario de edición de perfil con Server Action
- [x] Storage `avatars` con políticas por carpeta `<uid>/...`
- [ ] Onboarding obligatorio (`/onboarding`, `profiles.is_complete`)
- [ ] Tabla `posts` y feed con listado
- [ ] Crear post (texto + imagen)
- [ ] Likes y contador

## Milestone 3 — UX y despliegue
- [x] Diseño base con tokens Tailwind (incluye dark mode por sistema)
- [ ] Layout de feed con **sidebar izquierda** (navegación) y **derecha** (social)
- [ ] Deploy en Vercel + Supabase
- [ ] Dominio personalizado

## Milestone 4 — Avanzado
- [ ] Realtime (notificaciones/chat)
- [ ] Sugerencias de usuarios y “gente que quizá conozcas”
- [ ] Tests (unitarios y e2e)
- [ ] Migración a TypeScript