# Arquitectura

## Stack
- **Next.js (App Router)** — UI + SSR/SSG + Server Actions.
- **Supabase** — PostgreSQL, Auth (email+password), Storage, Row Level Security.
- **Tailwind CSS** — utilidades y theming con design tokens.

## Enrutado (App Router)
- Rutas públicas: `/`, `/login`, `/signup`.
- Rutas protegidas: `/feed`, `/profile/edit` (y próximamente `/onboarding`).
- **Route Group `(auth)`**: organiza vistas de autenticación sin prefijo en la URL.
  
