// app/profile/edit/actions.js
"use server";

import { createServerSupabase } from "@/lib/supabaseServer";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

export async function updateProfile(prevState, formData) {
  const supabase = createServerSupabase();

  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { ok: false, message: "No autorizado" };

  // viene del <input type="hidden" name="onboarding" />
  const onboarding = (formData.get("onboarding") || "0") === "1";

  const payload = {
    username: (formData.get("username") || "").toString().trim() || null,
    full_name: (formData.get("full_name") || "").toString().trim() || null,
    bio: (formData.get("bio") || "").toString().trim() || null,
    avatar_url: (formData.get("avatar_url") || "").toString().trim() || null,
  };

  const { error } = await supabase
    .from("profiles")
    .update(payload)
    .eq("id", user.id);

  if (error) {
    if (error.code === "23505")
      return { ok: false, message: "Ese username ya existe." };
    return { ok: false, message: error.message };
  }

  // Asegura que el SSR recoja los cambios si nos quedamos en esta página
  revalidatePath("/profile/edit");

  // Si estamos en onboarding y YA hay username + avatar -> vamos al feed
  if (onboarding) {
    const { data: p } = await supabase
      .from("profiles")
      .select("username, avatar_url")
      .eq("id", user.id)
      .single();

    if (p?.username && p?.avatar_url) {
      redirect("/feed");
    }
  }

  // Modo “edición normal”: nos quedamos y mostramos el mensaje
  return { ok: true, message: "Perfil actualizado ✅" };
}
