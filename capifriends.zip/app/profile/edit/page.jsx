// (Server Component: NO "use client")
// Lee sesión y perfil en el servidor y renderiza el formulario.
import { createServerSupabase } from "@/lib/supabaseServer";
import EditProfileForm from "../../../components/profile/EditProfileForm";
import { updateProfile } from "./actions";

export default async function Page({ searchParams }) {
  // 1) Creamos cliente server-side (lee cookies automáticamente)
  const supabase = await createServerSupabase();

  // 2) Obtenemos la sesión; si no hay, el middleware te habrá redirigido a /login
  const {
    data: { session },
  } = await supabase.auth.getSession();
  if (!session) return null;

  // 3) Leemos la fila del perfil del usuario autenticado
  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", session.user.id)
    .single();
    
  const onboarding = searchParams?.onboarding === "1";
  
  // 4) Devolvemos el formulario (Client Component) con datos iniciales y la server action
  return <EditProfileForm initial={profile} action={updateProfile} onboarding={onboarding} />;
}
