"use client";
/**
 * Formulario para crear posts.
 * - Texto obligatorio (min 1 char)
 * - Imagen opcional: sube a Storage en bucket "post-images" bajo <uid>/...
 * - Llama a la Server Action `createPost`.
 */
import { useState, useActionState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { createPost } from "@/app/feed/actions";

export default function PostComposer() {
  const [content, setContent] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [localMsg, setLocalMsg] = useState("");

  // Vinculamos la server action al <form>
  const [state, formAction] = useActionState(createPost, null);

  async function onPickImage(e) {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validaciones mínimas
    const okTypes = ["image/png", "image/jpeg", "image/webp", "image/gif"];
    if (!okTypes.includes(file.type)) {
      setLocalMsg("Formato no soportado. Usa PNG/JPG/WEBP/GIF.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setLocalMsg("Máximo 5MB.");
      return;
    }

    // Necesitamos el uid para subir a <uid>/...
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setLocalMsg("Sesión no encontrada. Inicia sesión de nuevo.");
      return;
    }

    // Sube a Storage (bucket 'post-images'), ruta <uid>/<timestamp>_nombre
    const path = `${user.id}/${Date.now()}_${file.name}`;
    const { error } = await supabase.storage
      .from("post-images")
      .upload(path, file, { upsert: true });

    if (error) {
      setLocalMsg(error.message);
      return;
    }

    // Obtenemos URL pública (el bucket es público)
    const { data: pub } = supabase.storage
      .from("post-images")
      .getPublicUrl(path);
    setImageUrl(pub.publicUrl);
    setLocalMsg("Imagen subida ✅");
  }

  return (
    <form
      action={async (formData) => {
        setLocalMsg("");
        // añadimos la imageUrl al submit (si la hay)
        if (imageUrl) formData.set("image_url", imageUrl);
        await formAction(formData);
        // limpia el textarea si se creó el post
        if (!state?.error) setContent("");
      }}
      className="border rounded-xl p-4 space-y-3"
    >
      <textarea
        name="content"
        value={content}
        onChange={(e) => setContent(e.target.value)}
        rows={3}
        placeholder="¿Qué estás pensando?"
        className="w-full border rounded p-2"
        required
      />

      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <input type="file" accept="image/*" onChange={onPickImage} />
          {imageUrl && (
            <span className="text-xs text-muted-foreground truncate max-w-48">
              Imagen lista
            </span>
          )}
        </div>

        <button className="px-4 py-1.5 rounded bg-brand text-white">
          Publicar
        </button>
      </div>

      {/* mensajes */}
      {localMsg && <p className="text-sm">{localMsg}</p>}
      {state?.message && (
        <p className={`text-sm ${state.error ? "text-red-600" : ""}`}>
          {state.message}
        </p>
      )}
    </form>
  );
}
