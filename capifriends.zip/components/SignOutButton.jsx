"use client";
import { supabase } from "@/lib/supabaseClient";
import { useRouter } from "next/navigation";

export default function SignOutButton({ className = "" }) {
  const router = useRouter();

  async function onSignOut() {
    await supabase.auth.signOut();
    // refresh() fuerza a Next a re-hidratar con sesión nula
    router.refresh();
    router.push("/");
  }

  return (
    <button type="button" onClick={onSignOut} className={className}>
      Cerrar sesión
    </button>
  );
}
