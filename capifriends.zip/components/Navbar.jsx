import { createServerSupabase } from "@/lib/supabaseServer";
import NavbarClient from "./NavbarClient";

export default async function Navbar() {
  const supabase = await createServerSupabase();
  const {
    data: { session },
  } = await supabase.auth.getSession();

  let profile = null;
  if (session?.user) {
    const { data } = await supabase
      .from("profiles")
      .select("username, full_name, avatar_url")
      .eq("id", session.user.id)
      .single();
    profile = data ?? null;
  }

  return <NavbarClient user={session?.user ?? null} profile={profile} />;
}
